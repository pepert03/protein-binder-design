import os,sys,time,threading,json,hashlib,collections,typing
from pathlib import Path
import torch
from omegaconf.dictconfig import DictConfig
from omegaconf.listconfig import ListConfig
from omegaconf.base import ContainerMetadata,Metadata
from omegaconf.nodes import AnyNode
cache=Path(os.environ['BOLTZ_CACHE'])
root=Path(os.environ['PB_ROOT'])
from boltz.main import download_boltz2
# Descarga estándar del paquete. No se envían secuencias.
download_boltz2(cache)
p=cache/'boltz2_conf.ckpt'
allowed=[DictConfig,ListConfig,ContainerMetadata,Metadata,AnyNode,int,list,dict,typing.Any,collections.defaultdict]
if hasattr(torch.serialization,'get_unsafe_globals_in_checkpoint'):
    observed=set(torch.serialization.get_unsafe_globals_in_checkpoint(p))
    names={'omegaconf.dictconfig.DictConfig','omegaconf.listconfig.ListConfig','omegaconf.base.ContainerMetadata','omegaconf.base.Metadata','omegaconf.nodes.AnyNode','builtins.int','builtins.list','builtins.dict','typing.Any','collections.defaultdict'}
    assert observed<=names, 'Clases no revisadas en checkpoint: '+str(observed-names)
torch.serialization.add_safe_globals(allowed)
with p.open('rb') as f:
    h=hashlib.file_digest(f,'sha256').hexdigest()
(root/'checkpoint_sha256.txt').write_text(h)
memtotal=int(next(l.split()[1] for l in open('/proc/meminfo') if l.startswith('MemTotal:')))
cap=min(22*1024**2,int(memtotal*.85))
def guard():
    while True:
        with open('/proc/self/status') as f:
            rss=int(next(l.split()[1] for l in f if l.startswith('VmRSS:')))
        if rss>cap:
            print('RAM_GUARD_STOPPED',rss,'KiB',flush=True);os._exit(3)
        time.sleep(.5)
threading.Thread(target=guard,daemon=True).start()
print('SAFE_ALLOWLIST; RAM_CAP_KiB',cap,flush=True)
from boltz.main import cli
cli()
